import { CustomerOrder } from './customer-order';

describe('CustomerOrder', () => {
  it('should create an instance', () => {
    expect(new CustomerOrder()).toBeTruthy();
  });
});
